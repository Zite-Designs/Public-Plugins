<?php

declare(strict_types=1);

namespace YtDesigns\CustomEnchantments\commands;

use YtDesigns\TimedBroadcaster\args;
use CortexPE\Commando\BaseCommand;
use CortexPE\Commando\BaseSubCommand;
use YtDesigns\CustomEnchantments\commands\subcommands\AboutSubCommand;
use YtDesigns\CustomEnchantments\commands\subcommands\EnchantSubCommand;
use YtDesigns\CustomEnchantments\commands\subcommands\InfoSubCommand;
use YtDesigns\CustomEnchantments\commands\subcommands\ListSubCommand;
use YtDesigns\CustomEnchantments\commands\subcommands\NBTSubCommand;
use YtDesigns\CustomEnchantments\commands\subcommands\RemoveSubCommand;
use YtDesigns\CustomEnchantments\CustomEnchantments;
use jojoe77777\FormAPI\SimpleForm;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class CustomEnchantsCommand extends BaseCommand
{
    /** @var CustomEnchantments */
    protected $plugin;

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        $subcommands = array_values(array_map(function (BaseSubCommand $subCommand): string {
            return $subCommand->getName();
        }, $this->getSubCommands()));
        if ($sender instanceof Player && $this->plugin->areFormsEnabled()) {
            $form = new SimpleForm(function (Player $player, ?int $data) use ($subcommands): void {
                if ($data !== null && isset($subcommands[$data])) {
                    $this->plugin->getServer()->dispatchCommand($player, "ce " . $subcommands[$data]);
                }
            });
            $form->setTitle(args::INFO . "CustomEnchantments Menu");
            foreach ($subcommands as $subcommand) $form->addButton(ucfirst($subcommand));
            $sender->sendForm($form);
            return;
        }
        $sender->sendMessage(args::USAGE . "/ce <" . implode("|", $subcommands) . ">");
    }

    public function prepare(): void
    {
        $this->registerSubCommand(new EnchantSubCommand($this->plugin, "enchant", "Apply an enchantment on an item"));
        $this->registerSubCommand(new InfoSubCommand($this->plugin, "info", "Get info on a custom enchant"));
        $this->registerSubCommand(new ListSubCommand($this->plugin, "list", "Lists all registered custom enchants"));
        $this->registerSubCommand(new RemoveSubCommand($this->plugin, "remove", "Remove an enchantment from an item"));
    }
}
