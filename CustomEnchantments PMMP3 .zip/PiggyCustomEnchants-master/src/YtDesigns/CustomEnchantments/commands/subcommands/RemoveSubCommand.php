<?php

declare(strict_types=1);

namespace YtDesigns\CustomEnchantments\commands\subcommands;

use YtDesigns\TimedBroadcaster\args;
use CortexPE\Commando\args\RawStringArgument;
use CortexPE\Commando\BaseSubCommand;
use CortexPE\Commando\exception\ArgumentOrderException;
use YtDesigns\CustomEnchantments\CustomEnchantManager;
use YtDesigns\CustomEnchantments\CustomEnchantments;
use YtDesigns\CustomEnchantments\utils\Utils;
use jojoe77777\FormAPI\CustomForm;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class RemoveSubCommand extends BaseSubCommand
{
    /** @var CustomEnchantments */
    protected $plugin;

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if ($sender instanceof Player && $this->plugin->areFormsEnabled() && !isset($args["enchantment"])) {
            $this->onRunForm($sender, $aliasUsed, $args);
            return;
        }
        if ((!$sender instanceof Player && empty($args["player"])) || !isset($args["enchantment"])) {
            $sender->sendMessage(args::USAGE . "\\ce remove <enchantment> <player>");
            return;
        }
        $target = empty($args["player"]) ? $sender : $this->plugin->getServer()->getPlayer($args["player"]);
        if (!$target instanceof Player) {
            $sender->sendMessage(args::ERROR . "Invalid player.");
            return;
        }
        $enchant = CustomEnchantManager::getEnchantmentByName($args["enchantment"]);
        if ($enchant === null) {
            $sender->sendMessage(args::ERROR . "Invalid enchantment.");
            return;
        }
        $item = $target->getInventory()->getItemInHand();
        if ($item->getEnchantment($enchant->getId()) === null) {
            $sender->sendMessage(args::ERROR . "Item does not have specified enchantment.");
            return;
        }
        $item->removeEnchantment($enchant->getId());
        if (count($item->getEnchantments()) === 0) $item->removeEnchantments();
        $sender->sendMessage(args::SUCCESS . "Enchantment successfully removed.");
        $target->getInventory()->setItemInHand($item);
    }

    public function onRunForm(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if ($sender instanceof Player) {
            $form = new CustomForm(function (Player $player, ?array $data): void {
                if ($data !== null) {
                    $enchant = is_numeric($data[0]) ? CustomEnchantManager::getEnchantment((int)$data[0]) : CustomEnchantManager::getEnchantmentByName($data[0]);
                    if ($enchant == null) {
                        Utils::errorForm($player, args::ERROR . "Invalid enchantment.");
                        return;
                    }
                    $target = $this->plugin->getServer()->getPlayer($data[1]);
                    if (!$target instanceof Player) {
                        Utils::errorForm($player, args::ERROR . "Invalid player.");
                        return;
                    }
                    $item = $target->getInventory()->getItemInHand();
                    if ($item->getEnchantment($enchant->getId()) === null) {
                        $player->sendMessage(args::ERROR . "Item does not have specified enchantment.");
                        return;
                    }
                    $item->removeEnchantment($enchant->getId());
                    if (count($item->getEnchantments()) === 0) $item->removeEnchantments();
                    $target->sendMessage(args::SUCCESS . "Enchantment successfully removed.");
                    $target->getInventory()->setItemInHand($item);
                }
            });
            $form->setTitle(args::INFO . "Remove Custom Enchantment");
            $form->addInput("Enchantment");
            $form->addInput("Player", "", $sender->getName());
            $sender->sendForm($form);
        }
    }

    /**
     * @throws ArgumentOrderException
     */
    protected function prepare(): void
    {
        $this->setPermission("CustomEnchantments.command.ce.remove");
        $this->registerArgument(0, new RawStringArgument("enchantment", true));
        $this->registerArgument(1, new RawStringArgument("player", true));
    }
}
