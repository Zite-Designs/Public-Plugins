<?php

declare(strict_types=1);

namespace YtDesigns\CustomEnchantments;

use YtDesigns\CustomEnchantments\enchants\armor\AntiKnockbackEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\ArmoredEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\AttackerDeterrentEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\BerserkerEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\boots\JetpackEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\boots\MagmaWalkerEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\boots\StompEnchantment;
use YtDesigns\CustomEnchantments\enchants\armor\CactusEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\chestplate\ChickenEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\chestplate\ParachuteEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\chestplate\ProwlEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\chestplate\SpiderEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\chestplate\VacuumEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\CloakingEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\EndershiftEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\EnlightedEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\ForcefieldEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\GrowEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\HeavyEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\helmet\AntitoxinEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\helmet\FocusedEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\helmet\ImplantsEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\helmet\MeditationEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\MoltenEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\OverloadEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\PoisonousCloudEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\ReviveEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\SelfDestructEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\ShieldedEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\ShrinkEnchant;
use YtDesigns\CustomEnchantments\enchants\armor\TankEnchant;
use YtDesigns\CustomEnchantments\enchants\CustomEnchant;
use YtDesigns\CustomEnchantments\enchants\CustomEnchantIds;
use YtDesigns\CustomEnchantments\enchants\miscellaneous\AutoRepairEnchant;
use YtDesigns\CustomEnchantments\enchants\miscellaneous\LuckyCharmEnchant;
use YtDesigns\CustomEnchantments\enchants\miscellaneous\RadarEnchant;
use YtDesigns\CustomEnchantments\enchants\miscellaneous\SoulboundEnchant;
use YtDesigns\CustomEnchantments\enchants\miscellaneous\ToggleableEffectEnchant;
use YtDesigns\CustomEnchantments\enchants\tools\axes\LumberjackEnchant;
use YtDesigns\CustomEnchantments\enchants\tools\DrillerEnchant;
use YtDesigns\CustomEnchantments\enchants\tools\EnergizingEnchant;
use YtDesigns\CustomEnchantments\enchants\tools\ExplosiveEnchant;
use YtDesigns\CustomEnchantments\enchants\tools\hoe\FarmerEnchant;
use YtDesigns\CustomEnchantments\enchants\tools\hoe\FertilizerEnchant;
use YtDesigns\CustomEnchantments\enchants\tools\hoe\HarvestEnchant;
use YtDesigns\CustomEnchantments\enchants\tools\pickaxe\JackpotEnchant;
use YtDesigns\CustomEnchantments\enchants\tools\QuickeningEnchant;
use YtDesigns\CustomEnchantments\enchants\tools\SmeltingEnchant;
use YtDesigns\CustomEnchantments\enchants\tools\TelepathyEnchant;
use YtDesigns\CustomEnchantments\enchants\weapons\BlessedEnchant;
use YtDesigns\CustomEnchantments\enchants\weapons\bows\AutoAimEnchant;
use YtDesigns\CustomEnchantments\enchants\weapons\bows\BombardmentEnchant;
use YtDesigns\CustomEnchantments\enchants\weapons\bows\BountyHunterEnchant;
use YtDesigns\CustomEnchantments\enchants\weapons\bows\GrapplingEnchant;
use YtDesigns\CustomEnchantments\enchants\weapons\bows\HeadhunterEnchant;
use YtDesigns\CustomEnchantments\enchants\weapons\bows\HealingEnchant;
use YtDesigns\CustomEnchantments\enchants\weapons\bows\MissileEnchant;
use YtDesigns\CustomEnchantments\enchants\weapons\bows\MolotovEnchant;
use YtDesigns\CustomEnchantments\enchants\weapons\bows\ParalyzeEnchant;
use YtDesigns\CustomEnchantments\enchants\weapons\bows\PiercingEnchant;
use YtDesigns\CustomEnchantments\enchants\weapons\bows\ProjectileChangingEnchant;
use YtDesigns\CustomEnchantments\enchants\weapons\bows\ShuffleEnchant;
use YtDesigns\CustomEnchantments\enchants\weapons\bows\VolleyEnchant;
use YtDesigns\CustomEnchantments\enchants\weapons\ConditionalDamageMultiplierEnchant;
use YtDesigns\CustomEnchantments\enchants\weapons\DeathbringerEnchant;
use YtDesigns\CustomEnchantments\enchants\weapons\DeepWoundsEnchant;
use YtDesigns\CustomEnchantments\enchants\weapons\DisarmingEnchant;
use YtDesigns\CustomEnchantments\enchants\weapons\DisarmorEnchant;
use YtDesigns\CustomEnchantments\enchants\weapons\GooeyEnchant;
use YtDesigns\CustomEnchantments\enchants\weapons\HallucinationEnchant;
use YtDesigns\CustomEnchantments\enchants\weapons\LacedWeaponEnchant;
use YtDesigns\CustomEnchantments\enchants\weapons\LifestealEnchant;
use YtDesigns\CustomEnchantments\enchants\weapons\LightningEnchant;
use YtDesigns\CustomEnchantments\enchants\weapons\VampireEnchant;
use pocketmine\entity\Effect;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\item\enchantment\Enchantment;
use ReflectionProperty;
use SplFixedArray;

class CustomEnchantManager
{
    /** @var CustomEnchantments */
    private static $plugin;

    /** @var CustomEnchant[] */
    public static $enchants = [];

    public static function init(CustomEnchantments $plugin): void
    {
        self::$plugin = $plugin;
        $vanillaEnchantments = new SplFixedArray(1024);

        $property = new ReflectionProperty(Enchantment::class, "enchantments");
        $property->setAccessible(true);
        foreach ($property->getValue() as $key => $value) {
            $vanillaEnchantments[$key] = $value;
        }
        $property->setValue($vanillaEnchantments);

        self::registerEnchantment(new AttackerDeterrentEnchant($plugin, CustomEnchantIds::CURSED, "Cursed", [Effect::WITHER], [60], [1], CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new AttackerDeterrentEnchant($plugin, CustomEnchantIds::DRUNK, "Drunk", [Effect::SLOWNESS, Effect::MINING_FATIGUE, Effect::NAUSEA], [60, 60, 60], [1, 1, 0]));
        self::registerEnchantment(new AttackerDeterrentEnchant($plugin, CustomEnchantIds::FROZEN, "Frozen", [Effect::SLOWNESS], [60], [1]));
        self::registerEnchantment(new AttackerDeterrentEnchant($plugin, CustomEnchantIds::HARDENED, "Hardened", [Effect::WEAKNESS], [60], [1], CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new AttackerDeterrentEnchant($plugin, CustomEnchantIds::POISONED, "Poisoned", [Effect::POISON], [60], [1], CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new AttackerDeterrentEnchant($plugin, CustomEnchantIds::REVULSION, "Revulsion", [Effect::NAUSEA], [20], [0], CustomEnchant::RARITY_UNCOMMON));

        self::registerEnchantment(new ConditionalDamageMultiplierEnchant($plugin, CustomEnchantIds::AERIAL, "Aerial", function (EntityDamageByEntityEvent $event) {
            return $event->getDamager()->isOnGround();
        }, CustomEnchant::RARITY_COMMON));
        self::registerEnchantment(new ConditionalDamageMultiplierEnchant($plugin, CustomEnchantIds::BACKSTAB, "Backstab", function (EntityDamageByEntityEvent $event) {
            return $event->getDamager()->getDirectionVector()->dot($event->getEntity()->getDirectionVector()) > 0;
        }, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new ConditionalDamageMultiplierEnchant($plugin, CustomEnchantIds::CHARGE, "Charge", function (EntityDamageByEntityEvent $event) {
            return $event->getDamager()->isSprinting();
        }, CustomEnchant::RARITY_UNCOMMON));

        self::registerEnchantment(new LacedWeaponEnchant($plugin, CustomEnchantIds::BLIND, "Blind", CustomEnchant::RARITY_COMMON, [Effect::BLINDNESS], [20], [0], [100]));
        self::registerEnchantment(new LacedWeaponEnchant($plugin, CustomEnchantIds::CRIPPLE, "Cripple", CustomEnchant::RARITY_COMMON, [Effect::NAUSEA, Effect::SLOWNESS], [100, 100], [0, 1]));
        self::registerEnchantment(new LacedWeaponEnchant($plugin, CustomEnchantIds::POISON, "Poison", CustomEnchant::RARITY_UNCOMMON, [Effect::POISON]));
        self::registerEnchantment(new LacedWeaponEnchant($plugin, CustomEnchantIds::WITHER, "Wither", CustomEnchant::RARITY_UNCOMMON, [Effect::WITHER]));

        self::registerEnchantment(new ProjectileChangingEnchant($plugin, CustomEnchantIds::BLAZE, "Blaze", "ZiteFireball"));
        self::registerEnchantment(new ProjectileChangingEnchant($plugin, CustomEnchantIds::HOMING, "Homing", "HomingArrow", 3, CustomEnchant::RARITY_MYTHIC));
        self::registerEnchantment(new ProjectileChangingEnchant($plugin, CustomEnchantIds::PORKIFIED, "Porkified", "PigProjectile", 3, CustomEnchant::RARITY_MYTHIC));
        self::registerEnchantment(new ProjectileChangingEnchant($plugin, CustomEnchantIds::WITHERSKULL, "Wither Skull", "ZiteWitherSkull", 1, CustomEnchant::RARITY_MYTHIC));

        self::registerEnchantment(new ToggleableEffectEnchant($plugin, CustomEnchantIds::ENRAGED, "Enraged", 5, CustomEnchant::TYPE_CHESTPLATE, CustomEnchant::ITEM_TYPE_CHESTPLATE, Effect::STRENGTH, -1));
        self::registerEnchantment(new ToggleableEffectEnchant($plugin, CustomEnchantIds::GEARS, "Gears", 1, CustomEnchant::TYPE_BOOTS, CustomEnchant::ITEM_TYPE_BOOTS, Effect::SPEED, 0, 0, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new ToggleableEffectEnchant($plugin, CustomEnchantIds::GLOWING, "Glowing", 1, CustomEnchant::TYPE_HELMET, CustomEnchant::ITEM_TYPE_HELMET, Effect::NIGHT_VISION, 0, 0, CustomEnchant::RARITY_COMMON));
        self::registerEnchantment(new ToggleableEffectEnchant($plugin, CustomEnchantIds::HASTE, "Haste", 5, CustomEnchant::TYPE_HAND, CustomEnchant::ITEM_TYPE_PICKAXE, Effect::HASTE, 0, 1, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new ToggleableEffectEnchant($plugin, CustomEnchantIds::OBSIDIANSHIELD, "Obsidian Shield", 1, CustomEnchant::TYPE_ARMOR_INVENTORY, CustomEnchant::ITEM_TYPE_ARMOR, Effect::FIRE_RESISTANCE, 0, 0, CustomEnchant::RARITY_COMMON));
        self::registerEnchantment(new ToggleableEffectEnchant($plugin, CustomEnchantIds::OXYGENATE, "Oxygenate", 1, CustomEnchant::TYPE_HAND, CustomEnchant::ITEM_TYPE_PICKAXE, Effect::WATER_BREATHING, 0, 0, CustomEnchant::RARITY_UNCOMMON));
        self::registerEnchantment(new ToggleableEffectEnchant($plugin, CustomEnchantIds::SPRINGS, "Springs", 1, CustomEnchant::TYPE_BOOTS, CustomEnchant::ITEM_TYPE_BOOTS, Effect::JUMP_BOOST, 3, 0, CustomEnchant::RARITY_UNCOMMON));

        self::registerEnchantment(new AntiKnockbackEnchant($plugin, CustomEnchantIds::ANTIKNOCKBACK));
        self::registerEnchantment(new AntitoxinEnchant($plugin, CustomEnchantIds::ANTITOXIN));
        self::registerEnchantment(new AutoAimEnchant($plugin, CustomEnchantIds::AUTOAIM));
        self::registerEnchantment(new AutoRepairEnchant($plugin, CustomEnchantIds::AUTOREPAIR));
        self::registerEnchantment(new ArmoredEnchant($plugin, CustomEnchantIds::ARMORED));
        self::registerEnchantment(new BerserkerEnchant($plugin, CustomEnchantIds::BERSERKER));
        self::registerEnchantment(new BlessedEnchant($plugin, CustomEnchantIds::BLESSED));
        self::registerEnchantment(new BombardmentEnchant($plugin, CustomEnchantIds::BOMBARDMENT));
        self::registerEnchantment(new BountyHunterEnchant($plugin, CustomEnchantIds::BOUNTYHUNTER));
        self::registerEnchantment(new CactusEnchant($plugin, CustomEnchantIds::CACTUS));
        self::registerEnchantment(new ChickenEnchant($plugin, CustomEnchantIds::CHICKEN));
        self::registerEnchantment(new CloakingEnchant($plugin, CustomEnchantIds::CLOAKING));
        self::registerEnchantment(new DeathbringerEnchant($plugin, CustomEnchantIds::DEATHBRINGER));
        self::registerEnchantment(new DeepWoundsEnchant($plugin, CustomEnchantIds::DEEPWOUNDS));
        self::registerEnchantment(new DisarmingEnchant($plugin, CustomEnchantIds::DISARMING));
        self::registerEnchantment(new DisarmorEnchant($plugin, CustomEnchantIds::DISARMOR));
        self::registerEnchantment(new DrillerEnchant($plugin, CustomEnchantIds::DRILLER));
        self::registerEnchantment(new EndershiftEnchant($plugin, CustomEnchantIds::ENDERSHIFT));
        self::registerEnchantment(new EnergizingEnchant($plugin, CustomEnchantIds::ENERGIZING));
        self::registerEnchantment(new EnlightedEnchant($plugin, CustomEnchantIds::ENLIGHTED));
        self::registerEnchantment(new ExplosiveEnchant($plugin, CustomEnchantIds::EXPLOSIVE));
        self::registerEnchantment(new FarmerEnchant($plugin, CustomEnchantIds::FARMER));
        self::registerEnchantment(new FertilizerEnchant($plugin, CustomEnchantIds::FERTILIZER));
        self::registerEnchantment(new FocusedEnchant($plugin, CustomEnchantIds::FOCUSED));
        self::registerEnchantment(new ForcefieldEnchant($plugin, CustomEnchantIds::FORCEFIELD));
        self::registerEnchantment(new GooeyEnchant($plugin, CustomEnchantIds::GOOEY));
        self::registerEnchantment(new GrapplingEnchant($plugin, CustomEnchantIds::GRAPPLING));
        self::registerEnchantment(new GrowEnchant($plugin, CustomEnchantIds::GROW));
        self::registerEnchantment(new HallucinationEnchant($plugin, CustomEnchantIds::HALLUCINATION));
        self::registerEnchantment(new HarvestEnchant($plugin, CustomEnchantIds::HARVEST));
        self::registerEnchantment(new HeadhunterEnchant($plugin, CustomEnchantIds::HEADHUNTER));
        self::registerEnchantment(new HealingEnchant($plugin, CustomEnchantIds::HEALING));
        self::registerEnchantment(new HeavyEnchant($plugin, CustomEnchantIds::HEAVY));
        self::registerEnchantment(new ImplantsEnchant($plugin, CustomEnchantIds::IMPLANTS));
        self::registerEnchantment(new JackpotEnchant($plugin, CustomEnchantIds::JACKPOT));
        self::registerEnchantment(new JetpackEnchant($plugin, CustomEnchantIds::JETPACK));
        self::registerEnchantment(new LifestealEnchant($plugin, CustomEnchantIds::LIFESTEAL));
        self::registerEnchantment(new LightningEnchant($plugin, CustomEnchantIds::LIGHTNING));
        self::registerEnchantment(new LuckyCharmEnchant($plugin, CustomEnchantIds::LUCKYCHARM));
        self::registerEnchantment(new LumberjackEnchant($plugin, CustomEnchantIds::LUMBERJACK));
        self::registerEnchantment(new MagmaWalkerEnchant($plugin, CustomEnchantIds::MAGMAWALKER));
        self::registerEnchantment(new MeditationEnchant($plugin, CustomEnchantIds::MEDITATION));
        self::registerEnchantment(new MissileEnchant($plugin, CustomEnchantIds::MISSILE));
        self::registerEnchantment(new MolotovEnchant($plugin, CustomEnchantIds::MOLOTOV));
        self::registerEnchantment(new MoltenEnchant($plugin, CustomEnchantIds::MOLTEN));
        self::registerEnchantment(new OverloadEnchant($plugin, CustomEnchantIds::OVERLOAD));
        self::registerEnchantment(new ParachuteEnchant($plugin, CustomEnchantIds::PARACHUTE));
        self::registerEnchantment(new ParalyzeEnchant($plugin, CustomEnchantIds::PARALYZE));
        self::registerEnchantment(new PiercingEnchant($plugin, CustomEnchantIds::PIERCING));
        self::registerEnchantment(new PoisonousCloudEnchant($plugin, CustomEnchantIds::POISONOUSCLOUD));
        self::registerEnchantment(new ProwlEnchant($plugin, CustomEnchantIds::PROWL));
        self::registerEnchantment(new QuickeningEnchant($plugin, CustomEnchantIds::QUICKENING));
        self::registerEnchantment(new RadarEnchant($plugin, CustomEnchantIds::RADAR));
        self::registerEnchantment(new ReviveEnchant($plugin, CustomEnchantIds::REVIVE));
        self::registerEnchantment(new SelfDestructEnchant($plugin, CustomEnchantIds::SELFDESTRUCT));
        self::registerEnchantment(new ShieldedEnchant($plugin, CustomEnchantIds::SHIELDED));
        self::registerEnchantment(new ShrinkEnchant($plugin, CustomEnchantIds::SHRINK));
        self::registerEnchantment(new ShuffleEnchant($plugin, CustomEnchantIds::SHUFFLE));
        self::registerEnchantment(new SmeltingEnchant($plugin, CustomEnchantIds::SMELTING));
        self::registerEnchantment(new SoulboundEnchant($plugin, CustomEnchantIds::SOULBOUND));
        self::registerEnchantment(new SpiderEnchant($plugin, CustomEnchantIds::SPIDER));
        self::registerEnchantment(new StompEnchantment($plugin, CustomEnchantIds::STOMP));
        self::registerEnchantment(new TankEnchant($plugin, CustomEnchantIds::TANK));
        self::registerEnchantment(new TelepathyEnchant($plugin, CustomEnchantIds::TELEPATHY));
        self::registerEnchantment(new VacuumEnchant($plugin, CustomEnchantIds::VACUUM));
        self::registerEnchantment(new VampireEnchant($plugin, CustomEnchantIds::VAMPIRE));
        self::registerEnchantment(new VolleyEnchant($plugin, CustomEnchantIds::VOLLEY));
    }

    public static function getPlugin(): CustomEnchantments
    {
        return self::$plugin;
    }

    public static function registerEnchantment(CustomEnchant $enchant): void
    {
        Enchantment::registerEnchantment($enchant);
        /** @var CustomEnchant $enchant */
        $enchant = Enchantment::getEnchantment($enchant->getId());
        self::$enchants[$enchant->getId()] = $enchant;

        self::$plugin->getLogger()->debug("Custom Enchantment '" . $enchant->getName() . "' registered with id " . $enchant->getId());
    }

    /**
     * @param int|Enchantment $id
     */
    public static function unregisterEnchantment($id): void
    {
        $id = $id instanceof Enchantment ? $id->getId() : $id;
        self::$enchants[$id]->unregister();
        self::$plugin->getLogger()->debug("Custom Enchantment '" . self::$enchants[$id]->getName() . "' unregistered with id " . self::$enchants[$id]->getId());
        unset(self::$enchants[$id]);

        $property = new ReflectionProperty(Enchantment::class, "enchantments");
        $property->setAccessible(true);
        $value = $property->getValue();
        unset($value[$id]);
        $property->setValue($value);
    }

    /**
     * @return CustomEnchant[]
     */
    public static function getEnchantments(): array
    {
        return self::$enchants;
    }

    public static function getEnchantment(int $id): ?CustomEnchant
    {
        return self::$enchants[$id] ?? null;
    }

    public static function getEnchantmentByName(string $name): ?CustomEnchant
    {
        foreach (self::$enchants as $enchant) {
            if (
                strtolower(str_replace(" ", "", $enchant->getName())) === strtolower(str_replace(" ", "", $name)) ||
                strtolower(str_replace(" ", "", $enchant->getDisplayName())) === strtolower(str_replace(" ", "", $name))
            ) return $enchant;
        }
        return null;
    }
}
