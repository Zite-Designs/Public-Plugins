<?php

declare(strict_types=1);

namespace YtDesigns\ZiteCustomEnchants\enchants\weapons;

use YtDesigns\ZiteCustomEnchants\enchants\ReactiveEnchantment;
use YtDesigns\ZiteCustomEnchants\ZiteCustomEnchants;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Event;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\Player;

class ConditionalDamageMultiplierEnchant extends ReactiveEnchantment
{
    /** @var callable */
    private $condition;

    public function __construct(ZiteCustomEnchants $plugin, int $id, string $name, callable $condition, int $rarity = self::RARITY_RARE)
    {
        $this->name = $name;
        $this->rarity = $rarity;
        $this->condition = $condition;
        parent::__construct($plugin, $id);
    }

    public function getDefaultExtraData(): array
    {
        return ["additionalMultiplier" => 0.1];
    }

    public function react(Player $player, Item $item, Inventory $inventory, int $slot, Event $event, int $level, int $stack): void
    {
        if ($event instanceof EntityDamageByEntityEvent) {
            if (($this->condition)($event)) {
                $event->setModifier($this->extraData["additionalMultiplier"] * $level, $this->getId());
            }
        }
    }
}