<?php

declare(strict_types=1);

namespace YtDesigns\CustomEnchantments\enchants;

use YtDesigns\CustomEnchantments\enchants\traits\ReactiveTrait;

class ReactiveEnchantment extends CustomEnchant
{
    use ReactiveTrait;
}