<?php

namespace ZiteDesigns\AccountUi\event\Balance;

use ZiteDesigns\AccountUi\event\AccountUiEvent;
use ZiteDesigns\AccountUi\AccountUi;

class PayBalanceEvent extends AccountUiEvent
{
    public static $handlerList;

    public function __construct(AccountUi $plugin, private $payer, private $target, private $amount)
    {
        parent::__construct($plugin, "PayCommand");
    }

    public function getPayer()
    {
        return $this->payer;
    }

    public function getTarget()
    {
        return $this->target;
    }

    public function getAmount()
    {
        return $this->amount;
    }
}
