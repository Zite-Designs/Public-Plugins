<?php


namespace ZiteDesigns\AccountUi\event\Balance;

use ZiteDesigns\AccountUi\AccountUi;
use ZiteDesigns\AccountUi\event\AccountUiEvent;

class BalanceChangedEvent extends AccountUiEvent
{
    public static $handlerList;

    public function __construct(AccountUi $plugin, private $username, private $newBalance, $issuer, private $oldBalance = null)
    {
        parent::__construct($plugin, $issuer);
    }

    /**
     * @return string
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * @return float
     * @deprecated
     */
    public function getBalance()
    {
        return $this->newBalance;
    }

    /**
     * @return float
     */
    public function getNewBalance()
    {
        return $this->newBalance;
    }


    /**
     * @return float|null
     */
    public function getOldBalance()
    {
        return $this->oldBalance;
    }
}
