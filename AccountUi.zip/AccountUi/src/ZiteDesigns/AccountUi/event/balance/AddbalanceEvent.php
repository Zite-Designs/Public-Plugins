<?php
namespace ZiteDesigns\AccountUi\event\Balance;

use ZiteDesigns\AccountUi\event\AccountUiEvent;
use ZiteDesigns\AccountUi\AccountUi;

class AddBalanceEvent extends AccountUiEvent
{
    public static $handlerList;

    public function __construct(AccountUi $plugin, private $username, private $amount, $issuer)
    {
        parent::__construct($plugin, $issuer);
    }

    public function getUsername()
    {
        return $this->username;
    }

    public function getAmount()
    {
        return $this->amount;
    }
}
