<?php


namespace ZiteDesigns\AccountUi\event\Balance;

use ZiteDesigns\AccountUi\event\AccountUiEvent;

use ZiteDesigns\AccountUi\AccountUi;

class SetBalanceEvent extends AccountUiEvent
{
    public static $handlerList;

    public function __construct(AccountUi $plugin, private $username, private $Balance, $issuer)
    {
        parent::__construct($plugin, $issuer);
        $this->username = $username;
        $this->Balance = $Balance;
    }

    public function getUsername()
    {
        return $this->username;
    }

    public function getBalance()
    {
        return $this->Balance;
    }
}
