<?php


namespace ZiteDesigns\AccountUi\event\account;

use ZiteDesigns\AccountUi\event\AccountUiEvent;
use ZiteDesigns\AccountUi\AccountUi;

class CreateAccountEvent extends AccountUiEvent
{

    public static $handlerList;

    public function __construct(AccountUi $plugin, private $username, private $defaultBalance, $issuer)
    {
        parent::__construct($plugin, $issuer);
    }

    public function getUsername()
    {
        return $this->username;
    }

    public function setDefaultBalance($Balance)
    {
        $this->defaultBalance = $Balance;
    }

    public function getDefaultBalance()
    {
        return $this->defaultBalance;
    }
}
