<?php

namespace ZiteDesigns\AccountUi\event;

use pocketmine\event\CancellableTrait;
use pocketmine\event\plugin\PluginEvent;
use pocketmine\event\Cancellable;

use ZiteDesigns\AccountUi\AccountUi;

class AccountUiEvent extends PluginEvent implements Cancellable
{
    use CancellableTrait;

    public function __construct(AccountUi $plugin, private $issuer)
    {
        parent::__construct($plugin);
    }

    public function getIssuer()
    {
        return $this->issuer;
    }
}
