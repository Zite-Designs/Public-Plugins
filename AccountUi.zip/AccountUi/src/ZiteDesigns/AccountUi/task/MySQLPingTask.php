<?php



namespace ZiteDesigns\AccountUi\task;


use ZiteDesigns\AccountUi\AccountUi;
use pocketmine\scheduler\Task;

class MySQLPingTask extends Task
{
    private $mysql;

    private $plugin;

    public function __construct(AccountUi $plugin, \mysqli $mysql)
    {
        $this->plugin = $plugin;

        $this->mysql = $mysql;
    }

    public function onRun(): void
    {
        if (!$this->mysql->ping()) {
            $this->plugin->openProvider();
        }
    }
}
