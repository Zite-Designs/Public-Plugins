<?php


namespace ZiteDesigns\AccountUi\task;

use ZiteDesigns\AccountUi\AccountUi;

use pocketmine\scheduler\Task;

class SaveTask extends Task
{

    public function __construct(private AccountUi $plugin) {}

    public function onRun(): void
    {
        $this->plugin->saveAll();
    }
}
