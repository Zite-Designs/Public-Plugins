<?php

namespace ZiteDesigns\AccountUi\provider;


use ZiteDesigns\AccountUi\AccountUi;
use pocketmine\player\Player;
use pocketmine\utils\Config;

class YamlProvider implements Provider{
	/**
	 * @var Config
	 */
	private $config;

	/** @var AccountUi */
	private $plugin;

	private $Balance = [];

	public function __construct(AccountUi $plugin){
		$this->plugin = $plugin;
	}

	public function open(){
		$this->config = new Config($this->plugin->getDataFolder() . "Balance.yml", Config::YAML, ["version" => 2, "Balance" => []]);
		$this->Balance = $this->config->getAll();
	}

	public function accountExists($player){
		if($player instanceof Player){
			$player = $player->getName();
		}
		$player = strtolower($player);

		return isset($this->Balance["Balance"][$player]);
	}

	public function createAccount($player, $defaultBalance = 1000){
		if($player instanceof Player){
			$player = $player->getName();
		}
		$player = strtolower($player);

		if(!isset($this->Balance["Balance"][$player])){
			$this->Balance["Balance"][$player] = $defaultBalance;
			return true;
		}
		return false;
	}

	public function removeAccount($player){
		if($player instanceof Player){
			$player = $player->getName();
		}
		$player = strtolower($player);

		if(isset($this->Balance["Balance"][$player])){
			unset($this->Balance["Balance"][$player]);
			return true;
		}
		return false;
	}

	public function getBalance($player){
		if($player instanceof Player){
			$player = $player->getName();
		}
		$player = strtolower($player);

		if(isset($this->Balance["Balance"][$player])){
			return $this->Balance["Balance"][$player];
		}
		return false;
	}

	public function setBalance($player, $amount){
		if($player instanceof Player){
			$player = $player->getName();
		}
		$player = strtolower($player);

		if(isset($this->Balance["Balance"][$player])){
			$this->Balance["Balance"][$player] = $amount;
			$this->Balance["Balance"][$player] = round($this->Balance["Balance"][$player], 2);
			return true;
		}
		return false;
	}

	public function addBalance($player, $amount){
		if($player instanceof Player){
			$player = $player->getName();
		}
		$player = strtolower($player);

		if(isset($this->Balance["Balance"][$player])){
			$this->Balance["Balance"][$player] += $amount;
			$this->Balance["Balance"][$player] = round($this->Balance["Balance"][$player], 2);
			return true;
		}
		return false;
	}

	public function reduceBalance($player, $amount){
		if($player instanceof Player){
			$player = $player->getName();
		}
		$player = strtolower($player);

		if(isset($this->Balance["Balance"][$player])){
			$this->Balance["Balance"][$player] -= $amount;
			$this->Balance["Balance"][$player] = round($this->Balance["Balance"][$player], 2);
			return true;
		}
		return false;
	}

	public function getAll(){
		return isset($this->Balance["Balance"]) ? $this->Balance["Balance"] : [];
	}

	public function save(){
		$this->config->setAll($this->Balance);
		$this->config->save();
	}

	public function close(){
		$this->save();
	}

	public function getName(){
		return "Yaml";
	}
}
