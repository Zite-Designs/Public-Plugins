<?php

namespace ZiteDesigns\AccountUi\provider;


use ZiteDesigns\AccountUi\AccountUi;
use ZiteDesigns\AccountUi\task\MySQLPingTask;

use pocketmine\player\Player;

class MySQLProvider implements Provider{
	/**
	 * @var \mysqli
	 */
	private $db;

	/** @var AccountUi */
	public function __construct(private AccountUi $plugin){
		$this->plugin = $plugin;
	}

	public function open(){
		$config = $this->plugin->getConfig()->get("provider-settings", []);

		$this->db = new \mysqli(
			$config["host"] ?? "1.1.1.1",
			$config["user"] ?? "ZiteDesigns",
			$config["password"] ?? "AccountUi",
			$config["db"] ?? "AccountUi",
			$config["port"] ?? 1000);
		if($this->db->connect_error){
			$this->plugin->getLogger()->critical("Could not connect to MySQL server: ".$this->db->connect_error);
			return;
		}
		if(!$this->db->query("CREATE TABLE IF NOT EXISTS user_Balance(
			username VARCHAR(20) PRIMARY KEY,
			Balance FLOAT
		);")){
			$this->plugin->getLogger()->critical("Error creating table: " . $this->db->error);
			return;
		}

		$this->plugin->getScheduler()->scheduleRepeatingTask(new MySQLPingTask($this->plugin, $this->db), 600);
	}

	/**
	 * @param \pocketmine\player\Player|string $player
	 * @return bool
	 */
	public function accountExists($player){
		if($player instanceof Player){
			$player = $player->getName();
		}
		$player = strtolower($player);

		$result = $this->db->query("SELECT * FROM user_Balance WHERE username='".$this->db->real_escape_string($player)."'");
		return $result->num_rows > 0 ? true:false;
	}

	/**
	 * @param \pocketmine\player\Player|string $player
	 * @param float $defaultBalance
	 * @return bool
	 */
	public function createAccount($player, $defaultBalance = 1000.0){
		if($player instanceof Player){
			$player = $player->getName();
		}
		$player = strtolower($player);

		if(!$this->accountExists($player)){
			$this->db->query("INSERT INTO user_Balance (username, Balance) VALUES ('".$this->db->real_escape_string($player)."', $defaultBalance);");
			return true;
		}
		return false;
	}

	/**
	 * @param \pocketmine\player\Player|string $player
	 * @return bool
	 */
	public function removeAccount($player){
		if($player instanceof Player){
			$player = $player->getName();
		}
		$player = strtolower($player);

		if($this->db->query("DELETE FROM user_Balance WHERE username='".$this->db->real_escape_string($player)."'") === true) return true;
		return false;
	}

	/**
	 * @param string $player
	 * @return float|bool
	 */
	public function getBalance($player){
		if($player instanceof Player){
			$player = $player->getName();
		}
		$player = strtolower($player);

		$res = $this->db->query("SELECT Balance FROM user_Balance WHERE username='".$this->db->real_escape_string($player)."'");
		$ret = $res->fetch_array()[0] ?? false;
		$res->free();
		return $ret;
	}

	/**
	 * @param \pocketmine\player\Player|string $player
	 * @param float $amount
	 * @return bool
	 */
	public function setBalance($player, $amount){
		if($player instanceof Player){
			$player = $player->getName();
		}
		$player = strtolower($player);

		$amount = (float) $amount;

		return $this->db->query("UPDATE user_Balance SET Balance = $amount WHERE username='".$this->db->real_escape_string($player)."'");
	}

	/**
	 * @param \pocketmine\player\Player|string $player
	 * @param float $amount
	 * @return bool
	 */
	public function addBalance($player, $amount){
		if($player instanceof Player){
			$player = $player->getName();
		}
		$player = strtolower($player);

		$amount = (float) $amount;

		return $this->db->query("UPDATE user_Balance SET Balance = Balance + $amount WHERE username='".$this->db->real_escape_string($player)."'");
	}

	/**
	 * @param \pocketmine\player\Player|string $player
	 * @param float $amount
	 * @return bool
	 */
	public function reduceBalance($player, $amount){
		if($player instanceof Player){
			$player = $player->getName();
		}
		$player = strtolower($player);

		$amount = (float) $amount;

		return $this->db->query("UPDATE user_Balance SET Balance = Balance - $amount WHERE username='".$this->db->real_escape_string($player)."'");
	}

	/**
	 * @return array
	 */
	public function getAll(){
		$res = $this->db->query("SELECT * FROM user_Balance");

		$ret = [];
		foreach($res->fetch_all() as $val){
			$ret[$val[0]] = $val[1];
		}

		$res->free();

		return $ret;
	}

	/**
	 * @return string
	 */
	public function getName(){
		return "MySQL";
	}

	public function save(){}

	public function close(){
		if($this->db instanceof \mysqli){
			$this->db->close();
		}
	}
}
