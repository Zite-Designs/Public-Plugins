<?php

namespace ZiteDesigns\AccountUi\provider;

use ZiteDesigns\AccountUi\AccountUi;

interface Provider{
	public function __construct(AccountUi $plugin);

	public function open();

	/**
	 * @param \pocketmine\player\Player|string $player
	 * @return bool
	 */
	public function accountExists($player);

	/**
	 * @param \pocketmine\player\Player|string $player
	 * @param float $defaultBalance
	 * @return bool
	 */
	public function createAccount($player, $defaultBalance = 1000);

	/**
	 * @param \pocketmine\player\Player|string $player
	 * @return bool
	 */
	public function removeAccount($player);

	/**
	 * @param string $player
	 * @return float|bool
	 */
	public function getBalance($player);

	/**
	 * @param \pocketmine\player\Player|string $player
	 * @param float $amount
	 * @return bool
	 */
	public function setBalance($player, $amount);

	/**
	 * @param \pocketmine\player\Player|string $player
	 * @param float $amount
	 * @return bool
	 */
	public function addBalance($player, $amount);

	/**
	 * @param \pocketmine\player\Player|string $player
	 * @param float $amount
	 * @return bool
	 */
	public function reduceBalance($player, $amount);

	/**
	 * @return array
	 */
	public function getAll();

	/**
	 * @return string
	 */
	public function getName();

	public function save();
	public function close();
}
