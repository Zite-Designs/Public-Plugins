<?php

namespace ZiteDesigns\AccountUi\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\TextFormat;
use pocketmine\player\Player;

use ZiteDesigns\AccountUi\AccountUi;

class SeeBalanceCommand extends Command
{

    public function __construct(private AccountUi $plugin)
    {
        $desc = $plugin->getCommandMessage("seebalance");
        parent::__construct("seebalance", $desc["description"], $desc["usage"]);

        $this->setPermission("AccountUi.command.seebalance");

        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $label, array $params): bool
    {
        if (!$this->plugin->isEnabled()) return false;
        if (!$this->testPermission($sender)) {
            return false;
        }

        $player = array_shift($params);
        if (trim($player) === "") {
            $sender->sendMessage(TextFormat::RED . "Usage: " . $this->getUsage());
            return true;
        }

        if (($p = $this->plugin->getServer()->getPlayerByPrefix($player)) instanceof Player) {
            $player = $p->getName();
        }

        $Balance = $this->plugin->myBalance($player);
        if ($Balance !== false) {
            $sender->sendMessage($this->plugin->getMessage("seeBalance-seeBalance", [$player, $Balance], $sender->getName()));
        } else {
            $sender->sendMessage($this->plugin->getMessage("player-never-connected", [$player], $sender->getName()));
        }
        return true;
    }
}
