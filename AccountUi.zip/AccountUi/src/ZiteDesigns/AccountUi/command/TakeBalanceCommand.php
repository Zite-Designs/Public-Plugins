<?php

namespace ZiteDesigns\AccountUi\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\TextFormat;
use pocketmine\player\Player;

use ZiteDesigns\AccountUi\AccountUi;

class TakeBalanceCommand extends Command
{

    public function __construct(private AccountUi $plugin)
    {
        $desc = $plugin->getCommandMessage("takebalance");
        parent::__construct("takebalance", $desc["description"], $desc["usage"]);

        $this->setPermission("AccountUi.command.takebalance");

        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $label, array $params): bool
    {
        if (!$this->plugin->isEnabled()) return false;
        if (!$this->testPermission($sender)) {
            return false;
        }

        $player = array_shift($params);
        $amount = array_shift($params);

        if (!is_numeric($amount)) {
            $sender->sendMessage(TextFormat::RED . "Usage: " . $this->getUsage());
            return true;
        }

        if (($p = $this->plugin->getServer()->getPlayerByPrefix($player)) instanceof Player) {
            $player = $p->getName();
        }

        if ($amount < 0) {
            $sender->sendMessage($this->plugin->getMessage("takeBalance-invalid-number", [$amount], $sender->getName()));
            return true;
        }

        $result = $this->plugin->reduceBalance($player, $amount, false, 'AccountUi.command.takebalance');
        switch ($result) {
            case AccountUi::RET_INVALID:
                $sender->sendMessage($this->plugin->getMessage("takeBalance-player-lack-of-Balance", [$player, $amount, $this->plugin->myBalance($player)], $sender->getName()));
                break;
            case AccountUi::RET_SUCCESS:
                $sender->sendMessage($this->plugin->getMessage("takeBalance-took-Balance", [$player, $amount], $sender->getName()));

                if ($p instanceof Player) {
                    $p->sendMessage($this->plugin->getMessage("takeBalance-Balance-taken", [$amount], $sender->getName()));
                }
                break;
            case AccountUi::RET_CANCELLED:
                $sender->sendMessage($this->plugin->getMessage("takeBalance-failed", [], $sender->getName()));
                break;
            case AccountUi::RET_NO_ACCOUNT:
                $sender->sendMessage($this->plugin->getMessage("player-never-connected", [$player], $sender->getName()));
                break;
        }

        return true;
    }
}
