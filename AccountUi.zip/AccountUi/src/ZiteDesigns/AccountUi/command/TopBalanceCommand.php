<?php


namespace ZiteDesigns\AccountUi\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;

use ZiteDesigns\AccountUi\AccountUi;
use ZiteDesigns\AccountUi\task\SortTask;

class TopBalanceCommand extends Command
{

    public function __construct(private AccountUi $plugin)
    {
        $desc = $plugin->getCommandMessage("topbalance");
        parent::__construct("topbalance", $desc["description"], $desc["usage"]);

        $this->setPermission("AccountUi.command.topbalance");

        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $label, array $params): bool
    {
        if (!$this->plugin->isEnabled()) return false;
        if (!$this->testPermission($sender)) return false;

        $page = (int)array_shift($params);

        $server = $this->plugin->getServer();

        $banned = [];
        foreach ($server->getNameBans()->getEntries() as $entry) {
            if ($this->plugin->accountExists($entry->getName())) {
                $banned[] = $entry->getName();
            }
        }
        $ops = [];
        foreach ($server->getOps()->getAll() as $op) {
            if ($this->plugin->accountExists($op)) {
                $ops[] = $op;
            }
        }

        $task = new SortTask($sender->getName(), $this->plugin->getAllBalance(), $this->plugin->getConfig()->get("add-op-at-rank"), $page, $ops, $banned);
        $server->getAsyncPool()->submitTask($task);
        return true;
    }
}
