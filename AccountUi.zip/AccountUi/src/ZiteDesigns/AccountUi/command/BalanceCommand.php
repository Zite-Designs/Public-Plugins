<?php

namespace ZiteDesigns\AccountUi\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\TextFormat;
use pocketmine\player\Player;

use ZiteDesigns\AccountUi\AccountUi;

class MyBalanceCommand extends Command{

	public function __construct(private AccountUi $plugin){
		$desc = $plugin->getCommandMessage("balance");
		parent::__construct("balance", $desc["description"], $desc["usage"]);

		$this->setPermission("AccountUi.command.balance");

		$this->plugin = $plugin;
	}

	public function execute(CommandSender $sender, string $label, array $params): bool{
		if(!$this->plugin->isEnabled()) return false;
		if(!$this->testPermission($sender)){
			return false;
		}

		if($sender instanceof Player){
			$Balance = $this->plugin->myBalance($sender);
			$sender->sendMessage($this->plugin->getMessage("balance-balance", [$Balance]));
			return true;
		}
		$sender->sendMessage(TextFormat::RED."Please run this command in-game.");
		return true;
	}
}
