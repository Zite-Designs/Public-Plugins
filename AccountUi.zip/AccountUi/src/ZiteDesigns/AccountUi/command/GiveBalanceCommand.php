<?php

namespace ZiteDesigns\AccountUi\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\TextFormat;
use pocketmine\player\Player;

use ZiteDesigns\AccountUi\AccountUi;

class GiveBalanceCommand extends Command{

	public function __construct(private AccountUi $plugin){
		$desc = $plugin->getCommandMessage("givebalance");
		parent::__construct("givebalance", $desc["description"], $desc["usage"]);

		$this->setPermission("AccountUi.command.givebalance");

		$this->plugin = $plugin;
	}

	public function execute(CommandSender $sender, string $label, array $params): bool{
		if(!$this->plugin->isEnabled()) return false;
		if(!$this->testPermission($sender)){
			return false;
		}

		$player = array_shift($params);
		$amount = array_shift($params);

		if(!is_numeric($amount)){
			$sender->sendMessage(TextFormat::RED . "Usage: " . $this->getUsage());
			return true;
		}

		if(($p = $this->plugin->getServer()->getPlayerByPrefix($player)) instanceof Player){
			$player = $p->getName();
		}

		$result = $this->plugin->addBalance($player, $amount,false,'AccountUi.command.givebalance');
		switch($result){
			case AccountUi::RET_INVALID:
			$sender->sendMessage($this->plugin->getMessage("giveBalance-invalid-number", [$amount], $sender->getName()));
			break;
			case AccountUi::RET_SUCCESS:
			$sender->sendMessage($this->plugin->getMessage("giveBalance-gave-Balance", [$amount, $player], $sender->getName()));

			if($p instanceof Player){
				$p->sendMessage($this->plugin->getMessage("giveBalance-Balance-given", [$amount], $sender->getName()));
			}
			break;
			case AccountUi::RET_CANCELLED:
			$sender->sendMessage($this->plugin->getMessage("request-cancelled", [], $sender->getName()));
			break;
			case AccountUi::RET_NO_ACCOUNT:
			$sender->sendMessage($this->plugin->getMessage("player-never-connected", [$player], $sender->getName()));
			break;
		}
        return true;
	}
}
