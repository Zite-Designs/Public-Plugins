<?php
namespace ZiteDesigns\AccountUi;

use pocketmine\permission\DefaultPermissions;
use pocketmine\permission\Permission;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\utils\Config;
use pocketmine\utils\Internet;
use pocketmine\utils\TextFormat;

use ZiteDesigns\AccountUi\provider\Provider;
use ZiteDesigns\AccountUi\provider\YamlProvider;
use ZiteDesigns\AccountUi\provider\MySQLProvider;
use ZiteDesigns\AccountUi\event\balance\SetbalanceEvent;
use ZiteDesigns\AccountUi\event\balance\ReducebalanceEvent;
use ZiteDesigns\AccountUi\event\balance\AddbalanceEvent;
use ZiteDesigns\AccountUi\event\balance\balanceChangedEvent;
use ZiteDesigns\AccountUi\event\account\CreateAccountEvent;
use ZiteDesigns\AccountUi\task\SaveTask;

class AccountUi extends PluginBase implements Listener
{
    const API_VERSION = 3;
    const PACKAGE_VERSION = "5.7";

    const RET_NO_ACCOUNT = -3;
    const RET_CANCELLED = -2;
    const RET_NOT_FOUND = -1;
    const RET_INVALID = 0;
    const RET_SUCCESS = 1;

    private static $instance = null;

    /** @var Provider */
    private $provider;


    /**
     * @param string $command
     * @param string|bool $lang
     *
     * @return array
     */
    public function getCommandMessage(string $command, $lang = false): array
    {

        $command = strtolower($command);
        if (isset($this->["commands"][$command])) {

    }

    /**
     * @param string $key
     * @param array $params
     * @param string $player
     *
     * @return string
     */


    public function getMonetaryUnit(): string
    {
        return $this->getConfig()->get("curency-symbol");
    }

    /**
     * @return array
     */
    public function getAllBalance(): array
    {
        return $this->provider->getAll();
    }

    /**
     * @param string|Player $player
     * @param float $defaultBalance
     * @param bool $force
     *
     * @return bool
     */
    public function createAccount($player, $defaultBalance = false, bool $force = false): bool
    {
        if ($player instanceof Player) {
            $player = $player->getName();
        }
        $player = strtolower($player);

        if (!$this->provider->accountExists($player)) {
            $defaultBalance = ($defaultBalance === false) ? $this->getConfig()->get("default-Balance") : $defaultBalance;

            $ev = new CreateAccountEvent($this, $player, $defaultBalance, "none");
            $ev->call();
            if (!$ev->isCancelled() or $force === true) {
                $this->provider->createAccount($player, $ev->getDefaultBalance());
            }
        }
        return false;
    }

    /**
     * @param string|Player $player
     *
     * @return bool
     */
    public function accountExists($player): bool
    {
        return $this->provider->accountExists($player);
    }

    /**
     * @param Player|string $player
     *
     * @return float|bool
     */
    public function myBalance($player)
    {
        return $this->provider->getBalance($player);
    }

    /**
     * @param string|Player $player
     * @param float $amount
     * @param bool $force
     * @param string $issuer
     *
     * @return int
     */
    public function setBalance($player, $amount, bool $force = false, string $issuer = "none"): int
    {
        if ($amount < 0) {
            return self::RET_INVALID;
        }

        if ($player instanceof Player) {
            $player = $player->getName();
        }
        $player = strtolower($player);
        if ($this->provider->accountExists($player)) {
            $amount = round($amount, 2);
            if ($amount > $this->getConfig()->get("max-Balance")) {
                return self::RET_INVALID;
            }

            $oldBalance = $this->provider->getBalance($player);
            if (!is_numeric($oldBalance)) $oldBalance = null;

            $ev = new SetBalanceEvent($this, $player, $amount, $issuer);
            $ev->call();
            if (!$ev->isCancelled() or $force === true) {
                $this->provider->setBalance($player, $amount);
                $ev2 = new BalanceChangedEvent($this, $player, $amount, $issuer, $oldBalance);
                $ev2->call();
                return self::RET_SUCCESS;
            }
            return self::RET_CANCELLED;
        }
        return self::RET_NO_ACCOUNT;
    }

    /**
     * @param string|Player $player
     * @param float $amount
     * @param bool $force
     * @param string $issuer
     *
     * @return int
     */
    public function addBalance($player, $amount, bool $force = false, $issuer = "none"): int
    {
        if ($amount < 0) {
            return self::RET_INVALID;
        }
        if ($player instanceof Player) {
            $player = $player->getName();
        }
        $player = strtolower($player);
        if (($Balance = $this->provider->getBalance($player)) !== false) {
            $amount = round($amount, 2);
            if ($Balance + $amount > $this->getConfig()->get("max-Balance")) {
                return self::RET_INVALID;
            }

            $ev = new AddBalanceEvent($this, $player, $amount, $issuer);
            $ev->call();
            if (!$ev->isCancelled() or $force === true) {
                $this->provider->addBalance($player, $amount);
                $ev2 = new BalanceChangedEvent($this, $player, $amount + $Balance, $issuer, $Balance);
                $ev2->call();
                return self::RET_SUCCESS;
            }
            return self::RET_CANCELLED;
        }
        return self::RET_NO_ACCOUNT;
    }

    /**
     * @param string|Player $player
     * @param float $amount
     * @param bool $force
     * @param string $issuer
     *
     * @return int
     */
    public function reduceBalance($player, $amount, bool $force = false, $issuer = "none"): int
    {
        if ($amount < 0) {
            return self::RET_INVALID;
        }
        if ($player instanceof Player) {
            $player = $player->getName();
        }
        $player = strtolower($player);
        if (($Balance = $this->provider->getBalance($player)) !== false) {
            $amount = round($amount, 2);
            if ($Balance - $amount < 0) {
                return self::RET_INVALID;
            }

            $ev = new ReduceBalanceEvent($this, $player, $amount, $issuer);
            $ev->call();
            if (!$ev->isCancelled() or $force === true) {
                $this->provider->reduceBalance($player, $amount);
                $ev2 = new BalanceChangedEvent($this, $player, $Balance - $amount, $issuer, $Balance);
                $ev2->call();
                return self::RET_SUCCESS;
            }
            return self::RET_CANCELLED;
        }
        return self::RET_NO_ACCOUNT;
    }

    /**
     * @return AccountUi
     */
    public static function getInstance(): self
    {
        return self::$instance;
    }

    public function onLoad(): void
    {
        self::$instance = $this;
    }

    public function onEnable(): void
    {
        $this->saveDefaultConfig();



        $this->initialize();

        if ($this->getConfig()->get("auto-save-time") > 0) {
            $this->getScheduler()->scheduleDelayedRepeatingTask(new SaveTask($this), $this->getConfig()->get("auto-save-time") * 1200, $this->getConfig()->get("auto-save-time") * 1200);
        }

        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    private function registerPermissions(): void
    {
        DefaultPermissions::registerPermission(new Permission("AccountUi.*", "functions of BankAccount it", [
            "AccountUi.command.setbalance",
            "AccountUi.command.balance",
            "AccountUi.command.addbalance",
            "AccountUi.command.pay",
            "AccountUi.command.seebalance",
            "AccountUi.command.topbalance",
            "AccountUi.command.takebalance",
        ]));
        DefaultPermissions::registerPermission(new Permission("AccountUi.*", "Allows to control all of functions in AccountUi", ["AccountUi.command.*"]));
    }

    public function onJoin(PlayerJoinEvent $event)
    {
        $player = $event->getPlayer();


        if (!$this->provider->accountExists($player)) {
            $this->getLogger()->debug("Account of '" . $player->getName() . "' is not found. Creating Bank account...");
            $this->createAccount($player, false, true);
        }
    }

    public function onDisable(): void
    {
        $this->saveAll();

        if ($this->provider instanceof Provider) {
            $this->provider->close();
        }
    }

    public function saveAll()
    {
        if ($this->provider instanceof Provider) {
            $this->provider->save();
        }
    }

    private function replaceParameters($message, $params = [])
    {
        $search = ["%CURRENCY_SYMBOL%"];
        $replace = [$this->getMonetaryUnit()];

        for ($i = 0; $i < count($params); $i++) {
            $search[] = "%" . ($i + 1);
            $replace[] = $params[$i];
        }

        $colors = [
            "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f", "k", "l", "m", "n", "o", "r"
        ];
        foreach ($colors as $code) {
            $search[] = "&" . $code;
            $replace[] = TextFormat::ESCAPE . $code;
        }

        return str_replace($search, $replace, $message);
    }

    private function initialize()
    {
        if ($this->getConfig()->get("check-update")) {
            $this->checkUpdate();
        }
        switch (strtolower($this->getConfig()->get("provider"))) {
            case "yaml":
                $this->provider = new YamlProvider($this);
                break;
            case "mysql":
                $this->provider = new MySQLProvider($this);
                break;
            default:
                $this->getLogger()->critical("Invalid database was given.");
                return false;
        }
        $this->provider->open();

        $this->initializeLanguage();
        $this->getLogger()->notice("Database provider was set to: " . $this->provider->getName());
        $this->registerPermissions();
        $this->registerCommands();
    }

    public function openProvider()
    {
        if ($this->provider !== null)
            $this->provider->open();
    }

    private function checkUpdate()
    {
        try {
            $info = json_decode(Internet::simpleCurl($this->getConfig()->get("update-host") . "?version=" . $this->getDescription()->getVersion() . "&package_version=" . self::PACKAGE_VERSION)->getBody(), true);
            if (!isset($info["status"]) or $info["status"] !== true) {
                $this->getLogger()->notice("isEnabled");
                return false;
            }
            if ($info["update-available"] === true) {
                $this->getLogger()->notice("Server says new version (" . $info["new-version"] . ") of AccountUi is out. Check it out at " . $info["download-address"]);
            }
            $this->getLogger()->notice($info["notice"]);
            return true;
        } catch (\Throwable $e) {
            $this->getLogger()->logException($e);
            return false;
        }
    }

    private function registerCommands()
    {
        $map = $this->getServer()->getCommandMap();

        $commands = [
            "balance" => "\\ZiteDesigns\\AccountUi\\command\\BalanceCommand",
            "topbalance" => "\\ZiteDesigns\\AccountUi\\command\\TopBalanceCommand",
            "setbalance" => "\\ZiteDesigns\\AccountUi\\command\\SetBalanceCommand",
            "seebalance" => "\\ZiteDesigns\\AccountUi\\command\\SeeBalanceCommand",
            "addbalance" => "\\ZiteDesigns\\AccountUi\\command\\BalanceCommand",
            "takebalance" => "\\ZiteDesigns\\AccountUi\\command\\TakeBalanceCommand",
            "pay" => "\\ZiteDesigns\\AccountUi\\command\\PayCommand",
        ];
        foreach ($commands as $cmd => $class) {
            $map->register("AccountUi", new $class($this));
        }
    }


}
}
